#!/usr/bin/env python3
import prompt
from random import randint
import math

