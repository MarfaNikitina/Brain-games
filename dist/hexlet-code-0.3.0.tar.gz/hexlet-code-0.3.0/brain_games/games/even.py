#!/usr/bin/env python3


def is_even(number):
    """функция считает число четное или нет"""
    if number % 2 == 0:
        return True
    else:
        return False