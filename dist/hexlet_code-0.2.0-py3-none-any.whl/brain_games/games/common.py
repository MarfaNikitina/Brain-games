#!/usr/bin/env python3
import prompt


def greet():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    if name:
        print('Hello, {}!'.format(name))
    return name


def congrats(name):
    print('Congratulations, {}!'.format(name))



def make_progression():
    num = randint(0, 10)
    step = randint(0, 10)
    next_num = num + step
    list_ = []
    for i in range(10):
        list_.append(next_num)
    secret_num = choice(list_)
    for index, item in enumerate(list_):
        if item == secret_num:
            list_[index] = '..'
    print(list_)
    for i in list_:
        rand_progression = '{} {} {} {} {} {} {} {} {} {}'.format(list_(i))
    return rand_progression
#an+1= an + d
#an = a1 + (n-1) * d