#!/usr/bin/env python3
import prompt
from brain_games.games.calc import create_random_expr
from brain_games.games.common import greet


def main():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    if name:
        print('Hello, {}!'.format(name))
    print('What is the result of the expression?')
    for i in range(3):
        ran_expression = create_random_expr()
        # print(f'Question: {ran_expression}')
        print('Question: {}'.format(ran_expression))
        true_answer = str(eval(ran_expression))
        answer = prompt.string('Your answer: ')
        if answer == true_answer:
            print('Correct!')
        else:
            print(
                "'{}' is wrong answer ;(. "
                "Correct answer was '{}'.".format(answer, true_answer)
            )
            print("Let's try again, {}!".format(name))
            break
    print('Congratulations, {}!'.format(name))


if __name__ == '__main__':
    main()
