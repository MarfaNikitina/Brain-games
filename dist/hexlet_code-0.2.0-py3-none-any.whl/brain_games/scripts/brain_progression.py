import prompt
from random import randint, choice


def main():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    if name:
        print('Hello, {}!'.format(name))
    print('What number is missing in the progression?')
    num = randint(0, 10)
    step = randint(0, 10)
    next_num = num + step
    list_ = []
    for i in range(6):
        list_.append(next_num)
    secret_num = choice(list_)
    print(secret_num)
    for index, item in enumerate(list_):
        if item == secret_num:
            list_[index] = '..'
        print(list_)
    for i in list_:
        rand_progression = ('{} {} {} {} {} {}'.format(list_(i))

    for i in range(3):
        print('Question: '.format(rand_progression))
        answer = prompt.string('Your answer: ')
        if answer == secret_num:
            print('Correct!')
        else:
            print(
                "'{}' is wrong answer ;(. "
                "Correct answer was '{}'.".format(answer, secret_num)
            )
            print("Let's try again, {}!".format(name))
            break
        print('Congratulations, {}!'.format(name))


if __name__ == '__main__':
    main()
