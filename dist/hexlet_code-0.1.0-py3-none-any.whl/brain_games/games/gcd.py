#!/usr/bin/env python3
import prompt
from random import randint
import math


def find_gcd():
    num1 = randint(1, 100)
    num2 = randint(1, 100)
    return math.gcd(num1, num2)